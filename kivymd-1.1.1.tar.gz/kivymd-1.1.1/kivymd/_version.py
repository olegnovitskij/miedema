# THIS FILE IS GENERATED FROM KIVYMD SETUP.PY
__version__ = '1.1.1'
__hash__ = 'ae3fee12f57797d3fe571b3baf64e2bb92e688d5'
__short_hash__ = 'ae3fee1'
__date__ = '2022-10-13'
